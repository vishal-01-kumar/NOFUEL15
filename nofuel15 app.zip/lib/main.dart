import 'package:flutter/material.dart';

void main() {
  runApp(VehicleApp());
}

class VehicleApp extends StatefulWidget {
  @override
  _VehicleAppState createState() => _VehicleAppState();
}

class _VehicleAppState extends State<VehicleApp> {
  bool isDarkMode = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NOFUEL15',
      debugShowCheckedModeBanner: false,
      theme: isDarkMode ? ThemeData.dark() : ThemeData.light(),
      home: HomeScreen(
        isDarkMode: isDarkMode,
        toggleTheme: () {
          setState(() => isDarkMode = !isDarkMode);
        },
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  final bool isDarkMode;
  final VoidCallback toggleTheme;

  HomeScreen({required this.isDarkMode, required this.toggleTheme});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _controller = TextEditingController();
  String? errorText;
  List<String> searchHistory = [];

  final Map<String, Map<String, dynamic>> vehicleDB = {
    "MH12AB1234": {
      "owner": "RAMESH SHARMA",
      "year": 2020,
      "history": ["2024-01-02", "2024-05-01", "2025-01-01"]
    },
    "DL8CAF2345": {
      "owner": "AJIT RATHORE",
      "year": 2002,
      "history": ["2024-03-15", "2024-12-01"]
    },
    "KA03XY4567": {
      "owner": "KESHAV JHA",
      "year": 2007,
      "history": ["2022-11-01", "2023-07-15", "2023-12-25"]
    },
  };

  int _selectedIndex = 0;

  void _handleSearch() {
    final input = _controller.text.toUpperCase().replaceAll(" ", "");
    if (input.isEmpty) {
      setState(() => errorText = "Please enter a number plate.");
      return;
    }

    if (!searchHistory.contains(input)) {
      setState(() {
        searchHistory.insert(0, input);
        if (searchHistory.length > 5) searchHistory.removeLast();
      });
    }

    if (vehicleDB.containsKey(input)) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => VehicleDetailsScreen(
            plate: input,
            data: vehicleDB[input]!,
            isDarkMode: widget.isDarkMode,
            toggleTheme: widget.toggleTheme,
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Vehicle not found. Fuel Blocked."),
        backgroundColor: Colors.redAccent,
      ));
    }
  }

  void _onHistoryTap(String plate) {
    _controller.text = plate;
    _handleSearch();
  }

  void _onNavTap(int index) {
    setState(() => _selectedIndex = index);
    // Future screens based on index can be added here
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('NOFUEL15 Vehicle Checker'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(widget.isDarkMode ? Icons.light_mode : Icons.dark_mode),
            tooltip: 'Toggle Theme',
            onPressed: widget.toggleTheme,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: ListView(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: "Enter Vehicle Number",
                errorText: errorText,
                prefixIcon: Icon(Icons.search),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onTap: () => setState(() => errorText = null),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                icon: Icon(Icons.search),
                label: Text("Check Vehicle"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: _handleSearch,
              ),
            ),
            const SizedBox(height: 30),
            if (searchHistory.isNotEmpty)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Recent Searches:', style: theme.textTheme.titleMedium),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    children: searchHistory
                        .map((plate) => ActionChip(
                              label: Text(plate),
                              onPressed: () => _onHistoryTap(plate),
                            ))
                        .toList(),
                  ),
                ],
              ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onNavTap,
        selectedItemColor: Colors.teal,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
          BottomNavigationBarItem(
              icon: Icon(Icons.settings), label: 'Settings'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About'),
        ],
      ),
    );
  }
}

class VehicleDetailsScreen extends StatelessWidget {
  final String plate;
  final Map<String, dynamic> data;
  final bool isDarkMode;
  final VoidCallback toggleTheme;

  const VehicleDetailsScreen({
    required this.plate,
    required this.data,
    required this.isDarkMode,
    required this.toggleTheme,
  });

  @override
  Widget build(BuildContext context) {
    final int age = 2025 - (data["year"] as int);
    final String status = age > 15 ? "Fuel Blocked" : "Fuel Allowed";
    final List history = data["history"];

    return Scaffold(
      appBar: AppBar(
        title: Text("Vehicle Details"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: Icon(isDarkMode ? Icons.light_mode : Icons.dark_mode),
            onPressed: toggleTheme,
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            _infoCard("Owner", data["owner"]),
            _infoCard("Plate", plate),
            _infoCard("Year of Manufacture", data["year"].toString()),
            _infoCard("Vehicle Age", "$age years"),
            _infoCard("Fuel Status", status,
                color: status == "Fuel Blocked" ? Colors.red : Colors.green),
            const SizedBox(height: 20),
            Text("Fuel Refill History:",
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            ...history.map((h) => ListTile(
                  leading: Icon(Icons.local_gas_station),
                  title: Text("Refilled on $h"),
                )),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0,
        selectedItemColor: Colors.teal,
        onTap: (index) {
          if (index == 0) Navigator.pop(context); // Go back to search
        },
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.search), label: 'Search Again'),
          BottomNavigationBarItem(
              icon: Icon(Icons.settings), label: 'Settings'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About'),
        ],
      ),
    );
  }

  Widget _infoCard(String title, String value, {Color? color}) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        title: Text(title),
        subtitle: Text(
          value,
          style: TextStyle(
              fontWeight: FontWeight.bold, color: color ?? Colors.black87),
        ),
      ),
    );
  }
}
