import 'package:flutter/material.dart';

void main() {
  runApp(VehicleApp());
}

class VehicleApp extends StatefulWidget {
  @override
  _VehicleAppState createState() => _VehicleAppState();
}

class _VehicleAppState extends State<VehicleApp> {
  bool isDarkMode = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NOFUEL15',
      debugShowCheckedModeBanner: false,
      theme: isDarkMode ? ThemeData.dark() : ThemeData.light(),
      home: VehicleChecker(
        isDarkMode: isDarkMode,
        toggleTheme: () {
          setState(() {
            isDarkMode = !isDarkMode;
          });
        },
      ),
    );
  }
}

class VehicleChecker extends StatefulWidget {
  final bool isDarkMode;
  final VoidCallback toggleTheme;

  VehicleChecker({required this.isDarkMode, required this.toggleTheme});

  @override
  _VehicleCheckerState createState() => _VehicleCheckerState();
}

class _VehicleCheckerState extends State<VehicleChecker>
    with SingleTickerProviderStateMixin {
  final TextEditingController _controller = TextEditingController();
  String? owner;
  int? age;
  String? status;
  bool showResult = false;
  List<String> searchHistory = [];

  final Map<String, Map<String, dynamic>> vehicleDB = {
    "MH12AB1234": {"owner": "John Doe", "year": 2010},
    "DL8CAF2345": {"owner": "Jane Smith", "year": 2000},
    "KA03XY4567": {"owner": "Amit Shah", "year": 2007},
  };

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 600));
    _fadeAnimation =
        CurvedAnimation(parent: _animationController, curve: Curves.easeInOut);
  }

  void checkVehicle() {
    final input = _controller.text.toUpperCase().replaceAll(" ", "");
    if (input.isEmpty) return;

    if (!searchHistory.contains(input)) {
      setState(() {
        searchHistory.insert(0, input);
        if (searchHistory.length > 5) searchHistory.removeLast();
      });
    }

    if (vehicleDB.containsKey(input)) {
      final vehicle = vehicleDB[input]!;
      final calculatedAge = 2025 - (vehicle["year"] as int);
      final fuelStatus = calculatedAge > 15 ? "Fuel Blocked" : "Fuel Allowed";

      setState(() {
        owner = vehicle["owner"];
        age = calculatedAge;
        status = fuelStatus;
        showResult = true;
      });
    } else {
      setState(() {
        owner = null;
        age = null;
        status = "Fuel Blocked";
        showResult = true;
      });
    }

    _animationController.forward(from: 0);
  }

  Widget buildStatusChip(String status) {
    final isAllowed = status == "Fuel Allowed";
    return Chip(
      label: Text(
        status,
        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
      ),
      backgroundColor: isAllowed ? Colors.green : Colors.red,
    );
  }

  Widget buildSearchHistory() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (searchHistory.isNotEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Text(
              'Recent Searches:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        Wrap(
          spacing: 10,
          children: searchHistory
              .map((plate) => ActionChip(
                    label: Text(plate),
                    onPressed: () {
                      _controller.text = plate;
                      checkVehicle();
                    },
                  ))
              .toList(),
        ),
      ],
    );
  }

  int _selectedIndex = 0;

  void onBottomNavTap(int index) {
    setState(() => _selectedIndex = index);
    // Future screens can be added here based on index
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = widget.isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text('NOFUEL15 Vehicle Checker'),
        actions: [
          IconButton(
            icon: Icon(isDark ? Icons.light_mode : Icons.dark_mode),
            tooltip: 'Toggle Theme',
            onPressed: widget.toggleTheme,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Enter Number Plate',
                prefixIcon: Icon(Icons.directions_car),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton.icon(
              icon: Icon(Icons.search),
              label: Text('Check Vehicle'),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                elevation: 5,
                backgroundColor: Colors.orangeAccent,
              ),
              onPressed: checkVehicle,
            ),
            SizedBox(height: 20),
            buildSearchHistory(),
            SizedBox(height: 30),
            if (showResult)
              FadeTransition(
                opacity: _fadeAnimation,
                child: Card(
                  color: isDark ? Colors.grey[850] : Colors.grey[100],
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          owner != null ? "Owner: $owner" : "Vehicle not found",
                          style: theme
                              .textTheme.bodyLarge, // Replaced to bodyLarge
                        ),
                        if (age != null)
                          Text("Vehicle Age: $age",
                              style: theme.textTheme
                                  .bodyLarge), // Replaced to bodyLarge
                        SizedBox(height: 10),
                        if (status != null) buildStatusChip(status!),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: onBottomNavTap,
        selectedItemColor: Colors.indigo,
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.directions_car), label: 'Checker'),
          BottomNavigationBarItem(
              icon: Icon(Icons.settings), label: 'Settings'),
          BottomNavigationBarItem(
              icon: Icon(Icons.info_outline), label: 'About'),
        ],
      ),
    );
  }
}
